@include('header')

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Feedback Form</title>
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #000;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 100%;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 50px 8%;
            position: absolute;
            top: 5%;
            right: 10%;
            height: 100%;
            width: 100%;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
        }

        input[type="text"],
        input[type="email"],
        textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #5c5c5c;
            border-radius: 3px;
            background: #181717;
            color: #fff;
        }

        textarea {
            height: 150px;
        }

        button {
            background-color: #00fff0;
            color: #222;
            padding: 10px 20px;
            border: none;
            border-radius: 30px;
            cursor: pointer;
            width: 100%;
        }

        button:hover {
            background-color: #007bff;
        }

        form input::placeholder,
        form textarea::placeholder {
            padding-left: 4px;
            color: #00fff0;
            transition: all 0.3s ease;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- <h2>Provide your Feedback</h2> -->
        <form action="feedback" method="POST">
            @csrf
            <div class="id">
                <label for="name"></label>
                <input type="text" id="name" name="name" placeholder="Your Name" required>
            </div>
            <div class="id">
                <label for="email"></label>
                <input type="email" id="email" name="email" placeholder="Your E-mail Id" required>
            </div>
            <div class="id">
                <label for="message"></label>
                <textarea id="message" name="message" placeholder="Enter your Feedback" required></textarea>
            </div>
            <button type="submit" name="sub">Submit</button>
        </form>
    </div>
</body>
</html>
@include('footer')
