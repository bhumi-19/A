@include('header')

<style>

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    .container {
        width: 100%;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 5%;
        right: 10%;
        height: 100%;
    }
    .product-item {
        margin: 20px;
        padding: 20px;
        border: 1px solid #ddd;
        border-radius: 5px;
        background-color: #fff;
        text-align: center;
        transition: transform 0.3s ease-in-out;
    }

    .product-item:hover {
        transform: scale(1.05);
    }

    .product-image {
        max-width: 100%;
        height: auto;
    }

    .product-title {
        font-size: 18px;
        margin-top: 10px;
    }


    .pagination {
        width: 100%;
        display: flex;
        justify-content: center;
        margin-top: 20px;
    }

    .pagination li {
        list-style: none;
        margin: 0 5px;
    }

    .pagination a {
        text-decoration: none;
        padding: 5px 10px;
        background-color: #009688;
        color: #fff;
        border-radius: 5px;
    }

    .pagination a:hover {
        background-color: #007a6e;
    }
</style>

<main>
    <div class="container">
        @csrf
        @isset($da)
            @foreach ($da as $k)
                <div class="col-3 product-item">
                    <a href="product2/{{ $k->category }}">
                        <img src="{{ asset('upload') }}/{{ $k->cimages }}" alt="{{ $k->category }}" class="product-image" width="300">
                        <h3 class="product-title">{{ $k->category }}</h3>
                    </a>
                </div>
            @endforeach
        @endisset
        <div class="pagination">
            {{ $da->links('pagination::bootstrap-5') }}
        </div>
    </div>

</main>

@include('footer')

