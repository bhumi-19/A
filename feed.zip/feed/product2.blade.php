@include('header')

<style>
    /* Reset some default styles */
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    /* Style for the product container */
    .container {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        padding: 50px 8%;
        position: absolute;
        top: 2%;
        left: 4%;
        height: 95%;
        width: 100%;
        align-items: center;
        /* justify-content: center; */
        /* padding: 50px 8%; */
        /* position: absolute; */
        /* top: 2%;
        left: 4%;
        height: 95%; */
    }

    /* Product Card Styles */
    .card {
    width: 250px;
    border: 1px solid #ccc;
    border-radius: 5px;
    overflow: hidden;
    margin-bottom: 20px !important; 
}



    .card img {
        max-width: 100%;
        height: auto;
    }

    .card-body {
        padding: 15px;
    }

    .card-title {
        font-size: 18px;
        font-weight: bold;
        margin-bottom: 10px;
    }

    .card-text {
        font-size: 14px;
        color: #555;
        margin-bottom: 15px;
    }

    .power {
        width: 100%;
        padding: 5px;
        margin-bottom: 15px;
        border: 1px solid #ccc;
        border-radius: 5px;
    }

    .card-price {
        font-size: 18px;
        font-weight: bold;
        color: green;
    }

    .add-to-cart-btn {
        display: block;
        width: 100%;
        padding: 10px;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    /* Pagination Styles */
    .pagination {
        justify-content: center;
        margin-top: 20px;
    }
</style>
<main>
        <main>
            <div class="container">
                <div class="row">
                    @isset($dat)
                    @if(count($dat)>0)
                    @foreach($dat as $product)
                    {{-- {{$product->}} --}}
                    <div class="col-3">
                        <form action="" method="post">
                            <div class="card m-2 cb1 text-center" style="width: 250px ; height: 400px;">
                                <img src="{{asset('upload')}}/{{$product->proimages}}" class="card-img-top"
                                    alt="..." height="150px" width="200px">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        {{$product->pname}}
                                    </h5>
                                    <p class="card-text">
                                        {{$product->des}}
                                    </p>
                                    {{-- <input type="text" class="power" name="power" value="$product['power']" placeholder="Enter Power"> --}}
                                     <select class="power">
                                        <option value="" selected="selected" hidden="" disabled="">Select Power
                                        </option>
                                        <option value="0.00">0.00</option>
                                        <option value="0.50">0.50</option>
                                        <option value="0.75">0.75</option>
                                        <option value="1.00">1.00</option>
                                        <option value="1.25">1.25</option>
                                        <option value="1.50">1.50</option>
                                        <option value="1.75">1.75</option>
                                        <option value="2.00">2.00</option>
                                        <option value="2.25">2.25</option>
                                        <option value="2.50">2.50</option>
                                        <option value="2.75">2.75</option>
                                        <option value="3.00">3.00</option>
                                        <option value="3.25">3.25</option>
                                        <option value="3.50">3.50</option>
                                        <option value="3.75">3.75</option>
                                        <option value="4.00">4.00</option>
                                        <option value="4.25">4.25</option>
                                        <option value="4.50">4.50</option>
                                        <option value="4.75">4.75</option>
                                        <option value="5.00">5.00</option>
                                        <option value="5.25">5.25</option>
                                        <option value="5.50">5.50</option>
                                        <option value="5.75">5.75</option>
                                        <option value="6.00">6.00</option>
                                        <option value="6.50">6.50</option>
                                        <option value="7.00">7.00</option>
                                        <option value="7.50">7.50</option>
                                        <option value="8.00">8.00</option>
                                        {{$product->power}}
                                    </select>
                                    <p class="card-text"> {{$product->price}}
                                    </p>
                                    <button name="cart" class="text-center text-dark ">
                                        Add To Cart
                                    </button>
                                </div>
                            </div>
                            <input type="hidden" name="hid" value="{{$product->pid}}">
                            <input type="hidden" name="hname" value="{{$product->pname}}">
                            <input type="hidden" name="hdes" value="{{$product->des}}">

                            <input type="hidden" name="hprice" value="{{$product->price}}">
                            <input type="hidden" name="himages" value="{{$product->proimages}}">
                            <input type="hidden" name="hpower" value="{{$product->power}}">
                            <input type="hidden" name="hqty" value="1">
                        </form>
                    </div>
                    @endforeach
                    @else
                    <h4>No category</h4>
                    @endif
                    @endisset
                </div>
                <div>
                    {{ $dat->links('pagination::bootstrap-5') }}
                </div>
            </div>

        </main>


@include('footer')
